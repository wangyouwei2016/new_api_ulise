# Console Noir — New API Frontend Theme Pack

Frontend-only homepage theme for **New API** (zero backend changes).

## Highlights

- **No version next to top-left logo**: hides the version badge in the public header, app header, and sidebar brand area.
- **Usage-focused homepage**:
  - Preserves the core slogan: `统一 API 网关，服务于海量 AI 模型` (`Unified API Gateway for Vast Range of AI Models`).
  - Interactive 5-channel client quickstart monitor (`Claude Code`, `Codex CLI`, `Gemini CLI`, `Cherry Studio`, `SDK / curl`) with live Gateway Base URL injection and one-click copy.
  - Preserves the 3-step **Workflow** section in an easy-to-edit file: `web/src/themes/console-noir/data/workflow-steps.ts`.
  - Dual Dark/Light theme tokens + optional subtle CRT scanline toggle in the bottom status bar.
- **Upgrade-friendly**: all theme code is isolated in `web/src/themes/console-noir/`, with minimal marker-delimited hooks in 6 frontend files.

## Apply to a New Version of New API

```bash
unzip console-noir-theme.zip -d /tmp/console-noir-theme
node /tmp/console-noir-theme/apply.mjs /path/to/new-api
cd /path/to/new-api/web && bun run build
```

## Customize the Workflow Later

Edit `web/src/themes/console-noir/data/workflow-steps.ts` to update step titles, descriptions, or links, then rebuild the frontend.

## Uninstall / Restore Default Theme

```bash
node /tmp/console-noir-theme/uninstall.mjs /path/to/new-api
```
