#!/usr/bin/env node
/**
 * Removes Console Noir frontend theme hooks and files cleanly.
 * Usage: node uninstall.mjs [path-to-new-api-repo]
 */
import fs from 'node:fs/promises'
import path from 'node:path'

const targetRoot = path.resolve(process.argv[2] || process.cwd())
const webRoot = path.join(targetRoot, 'web')
const MARKED_BLOCK_RE =
  /[ \t]*\/\* theme:console-noir:start \*\/[\s\S]*?\/\* theme:console-noir:end \*\/\n?/g

async function exists(p) {
  try {
    await fs.access(p)
    return true
  } catch {
    return false
  }
}

async function cleanFile(relPath, extraTransform) {
  const fullPath = path.join(targetRoot, relPath)
  if (!(await exists(fullPath))) return
  const original = await fs.readFile(fullPath, 'utf8')
  let updated = original.replace(MARKED_BLOCK_RE, '')
  if (extraTransform) {
    updated = extraTransform(updated)
  }
  if (updated !== original) {
    await fs.writeFile(fullPath, updated, 'utf8')
    console.log(`[restored] ${relPath}`)
  }
}

async function main() {
  await cleanFile('web/src/styles/index.css')

  await cleanFile('web/src/components/layout/components/public-header.tsx', (s) =>
    s
      .replace('  showVersion?: boolean\n', '')
      .replace('    showVersion = !CONSOLE_NOIR_THEME.hideBrandVersion,\n', '')
      .replace(
        "{showVersion && <SystemUpdateAction presentation='version' />}",
        "<SystemUpdateAction presentation='version' />"
      )
  )

  await cleanFile('web/src/components/layout/components/app-header.tsx', (s) =>
    s.replace(
      "{!CONSOLE_NOIR_THEME.hideBrandVersion && (\n          <SystemUpdateAction presentation='version' />\n        )}",
      "<SystemUpdateAction presentation='version' />"
    )
  )

  await cleanFile('web/src/components/layout/components/system-brand.tsx', (s) =>
    s.replace(
      "{!CONSOLE_NOIR_THEME.hideBrandVersion && (\n              <span className='truncate text-xs'>{version}</span>\n            )}",
      "<span className='truncate text-xs'>{version}</span>"
    )
  )

  await cleanFile('web/src/features/home/index.tsx', (s) =>
    s.replace(/\n{3,}(  return \()/g, '\n\n$1')
  )

  const themeDir = path.join(webRoot, 'src/themes/console-noir')
  await fs.rm(themeDir, { recursive: true, force: true })
  console.log('[removed] web/src/themes/console-noir')
  console.log('\nConsole Noir theme uninstalled.')
}

main().catch((err) => {
  console.error(err)
  process.exitCode = 1
})
